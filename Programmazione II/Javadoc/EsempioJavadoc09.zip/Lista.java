/*
 * Lista.java
 *
 * Created on 25 maggio 2004, 15.37
 */

package it.unipg.liste;

/**
 *La clase rappresenta una lista di interi
 * @author  gino2
 */
public class Lista {
    
    /** puntatore alla testa della lista */
    public Elemento testa; 

    
    /** visualizza gli elementi della lista; 
        versione <I> iterativa </I>*/
      public void visualizza()
      {int i = 1;
       for (Elemento e=testa;e!=null;e=e.next) 
       {System.out.println("Elemento "+i+" = " + e.valore); 
         i++;}

      } 
    
    /** visualizza gli elementi della lista; 
      *  versione <I> ricorsiva </I>*/
      
      public void visualizzar()
      {visualizzar(1,testa);
      }
      
    /** visualizza gli elementi della lista; 
      *  versione <I> ricorsiva </I>
      *  funzione di appoggio
      * @param i posizione
     * @param e puntatore alla testa della lista     
     */
      
      private void visualizzar(int i , Elemento e)
      { if (e != null ) 
        {System.out.println("Elemento "+i+" = " + e.valore);
         visualizzar(++i,e.next);
        }
      }
      
      
      public void visualizzar2()
      {visualizzar2(1,testa);
      }
      
      public void visualizzar2(int i , Elemento e)
      { if (e != null )         
        {visualizzar2(i+1,e.next);
         System.out.println("Elemento "+i+" = " + e.valore);
        }
      }
}



