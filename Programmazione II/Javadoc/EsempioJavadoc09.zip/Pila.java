/*
 * Pila.java
 *
 * Created on 25 maggio 2004, 15.36
 */

package it.unipg.liste;



/**
 *Classe che rappresenta un insieme di interi gestito con stratefia LIFO
 * 
* @author  gino2 
* @version  2.0 
*/

public class Pila extends Lista {
    
    
    
    /** Inserisce un elemento nella lista
     * @param valore  valore da inserire nella pila
     * @since prima lezione in laboratorio 
     */    
    public void inserisci (int valore)
    { Elemento nuovo;
      nuovo = new Elemento();
      nuovo.valore = valore;
      nuovo.next = testa;
      testa=nuovo;
    }
    
    /** Metodo per la conversione 
     * @param n  intero per {@link Lista} blablabla
     * @param s stringa da convertire
     * @return  oggetto Integer corrispondente alla stringa
     * @throws NumberFormatException  se la stringa non e` numerica
     */    
    public int prova (Integer n, String s) throws NumberFormatException{
        int i = 0;
        try {
             i = Integer.parseInt(s);
        }
        catch (NumberFormatException e)
        {
            throw e;
        }
    return i;
    }
    
        /** Metodo di estrazione di un elemento 
     * @return  Oggetto di classe Element che rappresenta il primo elemento della Pila
     * @see Elemento
     */   
     public   Elemento estraiElemento()
    {
        if(testa==null){
            return null;
        }
        else{
            Elemento a;
            a=testa;
            testa=testa.next;
            return a;
        }
    }
    
    
    /** Inizializza una pila vuota */    
  public  Pila ()
    { testa = null;
    }
}





