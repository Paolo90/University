/*
 * Pila.java
 *
 * Created on 25 maggio 2004, 15.36
 */

package it.unipg.liste;

/**
 *
 * @author  gino2
 */

/**
 *Classe che rappresenta un insieme di interi gestito con stratefia FIFO
 */
public class Coda extends Lista {
 
/**
 *Riferimento all'ultimo elemento della coda */
   Elemento ultimo=null;
	
    /** Inserisce un elemento nella lista <I>(Inserimento in coda) </I>
     * @param n valore da inserire nella pila
     * @since prima lezione in laboratorio 
     */    	
    void inserisci(int n){
       Elemento nuovo;//creo nuovo elemento
       nuovo = new Elemento();
       nuovo.dato = n;
       nuovo.next=null;
       if(ultimo==null)
           testa=nuovo;
       else
          ultimo.next=nuovo; //attacco alla struttura 
       ultimo=nuovo;
       
   }

   
           /** Metodo di estrazione di un elemento 
     * @return - Oggetto di classe Element che rappresenta il primo elemento della Pila
     * @see Elemento
     */  
     Elemento estraiElemento(){
        if(testa==null){
            return null;
        }
        else{
            Elemento a;
            a=testa;
            testa=testa.next;
            if(testa==null)
                ultimo=null;
            return a;
        }
    }
    
}
	
    
    
    