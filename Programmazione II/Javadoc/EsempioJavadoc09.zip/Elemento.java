/*
 * Elemento.java
 *
 * Created on 25 maggio 2004, 15.38
 */

package it.unipg.liste;

/**
 *Questa classe rappresenta un elemento di una lista di interi
 * @author  gino2
 */

public class Elemento {
	
		/**
		*Valore dell'elemento
		 */
		int valore;
                
		/**
		*Riferimento all'elemento successivo
		 */
	
		Elemento next;
	
	}



