javadoc -d docum *.java


javadoc -author -version -d docum *.java



javadoc -author -version -package -d docum *.java