package it.unipg.liste;

/*
 * ApplicazioneLista.java
 *
 * Created on 23 marzo 2004, 15.24
 */

// Nei commenti javadoc posso utilizzare anche i tag HTML

/**
 *Applicazione per esercitazione sulle <I>liste</I>
 *
 *
 * @version 1.0.0
 * @author  pizzosim
 */

public class ApplicazioneLista {
    
    /** Creates a new instance of ApplicazioneLista */
    public ApplicazioneLista() {
    }
    
    public static void main (String[] a)
    { int vettore [] = {1,3,5,7,9,2,4,6,8};
      Pila p;
      p = new Pila();
      for (int i=0;i<vettore.length;i++)
      {  p.inserisci(vettore[i]);
      }
      p.visualizza();
      p.visualizzar();
      p.visualizzar2();
    
    }
    
      
}
