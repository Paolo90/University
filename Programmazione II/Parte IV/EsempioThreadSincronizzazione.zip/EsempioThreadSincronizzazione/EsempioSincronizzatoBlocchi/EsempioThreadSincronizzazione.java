class Punto {
	int x = -1000000000, y = -1000000000;
	void sposta() { x++; y++; }
	void visualizza() {
		System.out.println("x=" + x + " y=" + y);
	}
	void controlla() {
		if(x-y !=0)
			System.out.println("x=" + x + " y=" + y);
	}

}


class Thread1 extends Thread 
{
	Punto punto;

	Thread1(Punto punto){
		this.punto=punto;
	}	


	public void run()
	{
		while (true)
		synchronized(punto){
			punto.sposta();
			
			}
	}

}

class Thread2 extends Thread 
{
	Punto punto;

	Thread2(Punto punto){
		this.punto=punto;
	}
	
	public void run()
	{
		
		while (true)
		{
			synchronized(punto){
				punto.visualizza();
			}	
}

	}

}

class Thread3 extends Thread 
{
	Punto punto;

	Thread3(Punto punto){
		this.punto=punto;
	}	

	public void run()
	{
		while (true)
			synchronized(punto){
				punto.controlla();
			}
	}

}




class EsempioThreadSincronizzazione {
	public static void main(String [] s)
		{

			Punto punto;
			punto = new Punto();
			Thread1 t1=new Thread1(punto);
			Thread2 t2=new Thread2(punto);
			Thread3 t3=new Thread3(punto);

			t1.start();
//			t2.start();
			t3.start();


		}

}
