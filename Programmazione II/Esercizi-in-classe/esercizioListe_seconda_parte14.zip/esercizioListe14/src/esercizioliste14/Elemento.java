/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizioliste14;

/**
 *
 * @author User
 */
public class Elemento {
    int valore;
    Elemento next;
    
    public Elemento(int valore,Elemento next){
        this.valore=valore;
        this.next=next;
    }
    
}
