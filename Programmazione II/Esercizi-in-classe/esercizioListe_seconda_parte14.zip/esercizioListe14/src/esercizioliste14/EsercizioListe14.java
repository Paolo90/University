/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizioliste14;

/**
 *
 * @author User
 */
public class EsercizioListe14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Lista l=new Lista(10);
        Lista l2;
        l.visualizza();
        l.visualizzaFor();
        l.visualizzaR();
        System.out.println("Somma elementi = "+l.somma());
        System.out.println("Somma elementi = "+l.sommaR());
        System.out.println("Elemento 2 =" + l.cercaEle(2));
        System.out.println("Elemento 1 =" + l.cercaEleR(1));
        System.out.println("Cancella 2 =" + l.cancellaEle(2));
        l.visualizza();
        l2 = l.listaInversa();
        l2.visualizza();
        
           
        
    }
}
