﻿/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizioliste14;

/**
 *
 * @author User
 */
public class Lista {
    Elemento testa=null;
    private int lunghezza = 0;
    
    public Lista(int n){
        for(int i=0; i<n; i++){
           testa= new Elemento((int)(Math.random()*10),testa);
           
        }
        lunghezza = n;
    } 
        
    void visualizza(){
        Elemento e=testa;
        while(e != null){
            System.out.print(e.valore+ " ");
            e=e.next;
    }
       System.out.println(" ");     
    }
    
    void visualizzaFor(){
        for(Elemento e=testa; e!= null; e=e.next){
            System.out.print(e.valore+ " ");
        }
        System.out.println(" ");
    }
    
    private void visualizzaR(Elemento e){
        if(e == null)
            System.out.println(" ");
        else{
            System.out.print(e.valore+ " ");
            visualizzaR(e.next);
        }
            
    }
    
    void visualizzaR(){
        visualizzaR(testa);
    }
    
    int somma(){
        int a=0;
        for(Elemento e=testa; e != null; e=e.next){
            a +=e.valore; // a=a+e.valore;
        }
        return a;
    }
    
    private int sommaR(Elemento e){
        if(e == null)
            return 0;
        else{
            return e.valore+sommaR(e.next);
        }
    }
    
    public int sommaR(){
        return sommaR(testa);  
    }
    
    /**
     * Complessità lineare rispetto al numero degli elementi
     * nel caso peggiore
     */
    
    public boolean cercaEle(int valore) {
        for(Elemento e = testa; e != null; e = e.next){
            if(e.valore == valore) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Complessità lineare rispetto al numero degli elementi
     * nel caso peggiore
     * Memoria necessaria lineare
     */
    
    private boolean cercaEleR(int valore, Elemento primo) {
        if(primo == null) {
            return false;
        } else {
            if(primo.valore == valore) {
                return true;
            } else {
               return cercaEleR(valore, primo.next);
            }
        }
    }
    
    public boolean cercaEleR(int valore) {
        return cercaEleR(valore, testa);
    }
    
    public int contaEle() {
        /*
        int conteggio = 0;
        for(Elemento e = testa; e != null; e = e.next){
            conteggio++;
        }
        return conteggio;
        */
        return lunghezza;
    }
    
    private int contaEleR(Elemento primo) {
        if(primo == null) {
            return 0;
        } else {
            return contaEleR(primo.next) + 1;
        }
    }
    
    public int contaEleR(){
        return contaEleR(testa);
    }
    
    public void inserisciEle (int valore) {
        Elemento e;
        e = new Elemento(valore, testa);
        testa = e;
        lunghezza++;
    }
    
    public boolean cancellaEle (int valore) {
        boolean temp = false;
        while(testa != null && testa.valore == valore) {
            testa = testa.next;
            lunghezza--;
            temp = true;
        }
        if(testa != null) {
            for(Elemento e = testa; e.next != null;){
                if(e.next.valore == valore){
                    e.next = e.next.next;
                    lunghezza--;
                    temp = true;
                } else {
                    e = e.next;
                }
            }
        }
        return temp;
    }
    
    public Lista listaInversa() {
        Lista l = new Lista(0);
        for(Elemento e = testa; e != null; e = e.next) {
            l.inserisciEle(e.valore); 
        }
        return l;
    }

}
