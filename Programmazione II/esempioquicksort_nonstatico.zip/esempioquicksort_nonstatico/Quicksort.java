import java.io.*;

class Quicksort extends Vettore{

   Quicksort(int n)
  {
  super(n);
  }


 public   void ordinaQuicksort () {
    quicks (v,0,v.length-1);
 }

 private int partition (int v[], int inizio, int fine) {
  int pivot = v[inizio];
  do
    {
    while (inizio < fine && v[fine] >= pivot)
      fine--;
    if (inizio < fine)
      {
      v[inizio]=v[fine];

      while (inizio < fine && v[inizio] <= pivot)
        inizio++;

      if (inizio < fine)
         v[fine] = v[inizio];
      }

    } while (inizio<fine);

    v[inizio] = pivot;

        try {
      stampa();
      System.out.println("mid = "+inizio);
      String letto =tastiera.readLine();
      } catch (IOException ecc) { }

    return inizio;
 }



  private void quicks (int v[], int inf, int sup) {
  if (inf < sup)
    {
    int mid = partition(v, inf, sup);
    quicks(v,inf,mid-1);
    quicks(v,mid+1,sup);
    }



 }



public static void main (String args[]) {
   String letto = null;
   BufferedReader tastiera = new BufferedReader(new InputStreamReader(System.in));
   System.out.print("Quanti elementi deve contenere il vettore?");
    try {
      letto =tastiera.readLine();
	    Quicksort Q = new Quicksort(Integer.parseInt(letto));
      Q.stampa();
      Q.riempiCasuale();
      Q.stampa();
      Q.ordinaQuicksort();
      Q.stampa();
      Q.riempi();
      Q.stampa();
      Q.ordinaQuicksort();
      Q.stampa();
      } catch (IOException ecc) { }
        catch (NumberFormatException ecc) { System.out.println("Formato errato!");}
 }
}
