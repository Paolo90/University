import java.io.*;

class Vettore {

BufferedReader tastiera = new BufferedReader(new InputStreamReader(System.in));

int v[];

Vettore(int n)
{
v = new int[n];
}


public void stampa () {
  System.out.print("v: [");
  System.out.print(v[0]);
  for (int i = 1; i < v.length; i++)
    {
    System.out.print(", ");
    System.out.print(v[i]);
    }
  System.out.println("]");
 }



public void riempi () {
   String letto = null;
  for (int i = 0; i < v.length; i++)
    {
    System.out.print("v[");
    System.out.print(i);
    System.out.print("]= ");
  try {
      letto =tastiera.readLine();
      v[i] = Integer.parseInt(letto);
    } catch (IOException ecc) { }
      catch (NumberFormatException ecc)
			 {     System.out.println("Formato errato!"); i--;}
    }
 }


public void riempiCasuale () {
    for (int i = 0; i < v.length; i++)
    {
      v[i] = (int) (Math.random()*100);
    }
 }

}
